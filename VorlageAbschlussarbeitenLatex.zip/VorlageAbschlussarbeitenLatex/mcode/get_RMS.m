function [y] = get_RMS(x, log_scale)
    
    % calculation rms_lin
    rms = sqrt(sum(x.^2)/length(x));
    
    % calcualtion rms_log, only if log_scale = true
    if log_scale
        rms = max(rms, realmin);
        y = 20*log10(rms);
    else
        y = rms;
    end

end

